import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-login-component',
  imports: [FormsModule, RouterLink],
  templateUrl: './login-component.html',
  styleUrl: './login-component.css',
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage = '';
  isLoading = false;

  onLogin() {
    this.isLoading = true;
    setTimeout(() => {
      console.log('Login user', { username: this.username});
      this.isLoading = false;
    }, 1000);
  }

}
