// services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap, catchError, throwError } from 'rxjs';
import { User } from '../models/user';
import { AuthResponse } from '../models/authResponse';
import { LoginRequest } from '../models/loginRequest';
import { LoggerService } from './logger-service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly API = 'https://api.example.com/auth';
  private readonly TOKEN_KEY = 'access_token';

  // BehaviorSubject хранит текущего пользователя реактивно
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router,
    private logger: LoggerService
  ) {
    this.restoreSession();
  }

  get currentUser(): User | null {
    return this.currentUserSubject.value;
  }

  get isLoggedIn(): boolean {
    return !!this.getToken();
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    this.logger.info('Попытка входа', credentials.email);

    return this.http.post<AuthResponse>(`${this.API}/login`, credentials).pipe(
      tap(response => {
        this.saveToken(response.accessToken);
        this.currentUserSubject.next(response.user);
        this.logger.info('Успешный вход', response.user.username);
      }),
      catchError(err => {
        this.logger.error('Ошибка входа', err.message);
        return throwError(() => err);
      })
    );
  }

  logout(): void {
    this.logger.info('Выход из системы');
    localStorage.removeItem(this.TOKEN_KEY);
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  private saveToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  private restoreSession(): void {
    const token = this.getToken();
    if (token) {
      this.logger.debug('Сессия восстановлена из localStorage');
    }
  }
}
