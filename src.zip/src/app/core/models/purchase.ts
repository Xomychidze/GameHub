export interface Purchase {
}
